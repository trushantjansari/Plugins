(function( $ ) {
	'use strict'; 
 
 


})( jQuery );
