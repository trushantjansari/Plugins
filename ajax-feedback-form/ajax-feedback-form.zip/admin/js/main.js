(function( $ ) {
	'use strict';

 


})( jQuery );
