<?php
/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 */
class Ajax_Feedback_Form_Deactivator {

    public static function deactivate() {
        

    }

}
